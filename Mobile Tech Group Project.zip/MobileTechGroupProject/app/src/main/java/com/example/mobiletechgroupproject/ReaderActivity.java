package com.example.mobiletechgroupproject;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

public class ReaderActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;

    private String readerType;
    private String currentFilename = "";
    private String resultText = "";
    private Uri imageFileUri;

    private ImageView imageView;
    private TextView textViewOutput;
    private Button btnEditResult;

    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {
                                if (result.getData() != null &&
                                        result.getData().getData() != null) {
                                    imageFileUri = result.getData().getData();
                                }
                                imageView.setImageURI(imageFileUri);
                                textViewOutput.setText("");

                                InputImage image = null;
                                try {
                                    image = InputImage.fromFilePath(
                                            getBaseContext(), imageFileUri);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (image != null) {
                                    if ("Barcode Reader".equals(readerType)) {
                                        processImageFromBarcodeReader(image);
                                    } else if ("Content Reader".equals(readerType)) {
                                        processImageFromContentReader(image);
                                    } else {
                                        processImageFromTextReader(image);
                                    }
                                }
                            }
                        }
                    });

    private final ActivityResultLauncher<String> requestCameraPermission =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) launchCamera();
                        else Toast.makeText(this,
                                "Camera permission required",
                                Toast.LENGTH_SHORT).show();
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);

        readerType = getIntent().getStringExtra("READER_TYPE");
        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(readerType);

        imageView      = findViewById(R.id.imageViewMLKit);
        textViewOutput = findViewById(R.id.textViewMLKit);
        btnEditResult  = findViewById(R.id.buttonEditResult);

        // Show same image as Activity 1
        if ("Barcode Reader".equals(readerType))
            imageView.setImageResource(R.drawable.barcode);
        else if ("Content Reader".equals(readerType))
            imageView.setImageResource(R.drawable.content);
        else
            imageView.setImageResource(R.drawable.text);

        btnEditResult.setVisibility(View.GONE);

        Button btnCamera = findViewById(R.id.buttonCamera);
        Button btnLoad   = findViewById(R.id.buttonLoadImage);

        btnCamera.setOnClickListener(v -> openCamera(v));
        btnLoad  .setOnClickListener(v -> loadImage(v));
        btnEditResult.setOnClickListener(v -> openEditActivity());
    }
    public void openCamera(View view) {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        currentFilename = String.valueOf(System.currentTimeMillis());
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }
    public void loadImage(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        currentFilename = String.valueOf(System.currentTimeMillis());
        activityResultLauncher.launch(galleryIntent);
    }

    private boolean checkPermission() {
        String permission = Manifest.permission.CAMERA;
        boolean granted = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            requestCameraPermission.launch(permission);
        }
        return granted;
    }

    private void launchCamera() {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        currentFilename = String.valueOf(System.currentTimeMillis());
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }
    public void processImageFromBarcodeReader(InputImage image) {
        TextView titleView = findViewById(R.id.textView);
        titleView.setText(readerType);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(readerType);

        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    textViewOutput.append(Html.fromHtml(
                            "<font color='black'><b>Detected barcode:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String result = "";
                    for (Barcode barcode : barcodes) {
                        result = barcode.getRawValue() != null
                                ? barcode.getRawValue() : "";
                        textViewOutput.append(result + "\n");
                    }
                    if (result.length() < 2) {
                        textViewOutput.append("Barcode not found.\n");
                    }
                    resultText = textViewOutput.getText().toString();
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed: " + e.getMessage()));
    }
    public void processImageFromContentReader(InputImage image) {
        TextView titleView = findViewById(R.id.textView);
        titleView.setText(readerType);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(readerType);

        ImageLabeler labeler = ImageLabeling.getClient(
                ImageLabelerOptions.DEFAULT_OPTIONS);

        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        textViewOutput.append("Nothing found in the image\n");
                        btnEditResult.setVisibility(View.VISIBLE);
                        return;
                    }
                    textViewOutput.append(Html.fromHtml(
                            "<font color='black'><b>Recognised image content:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        textViewOutput.append(counter + ". " + label.getText() + " (" + String.format("%.2f", label.getConfidence() * 100f) + "% confidence)\n");
                        counter++;
                        if (counter > 3) break;
                    }
                    resultText = textViewOutput.getText().toString();
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed: " + e.getMessage()));
    }
    public void processImageFromTextReader(InputImage image) {
        TextView titleView = findViewById(R.id.textView);
        titleView.setText(readerType);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(readerType);

        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    textViewOutput.append(Html.fromHtml(
                            "<font color='black'><b>Extracted text:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String result = visionText.getText();
                    if (result != null && result.length() > 1)
                        textViewOutput.append(result + "\n");
                    else
                        textViewOutput.append("No text found.\n");
                    resultText = textViewOutput.getText().toString();
                    btnEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewOutput.setText("Failed: " + e.getMessage()));
    }
    private void openEditActivity() {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra("READER_TYPE", readerType);
        intent.putExtra("RESULT_TEXT", resultText);
        intent.putExtra("FILENAME",    currentFilename);
        intent.putExtra("IMAGE_URI", imageFileUri.toString());
        startActivity(intent);
    }
}