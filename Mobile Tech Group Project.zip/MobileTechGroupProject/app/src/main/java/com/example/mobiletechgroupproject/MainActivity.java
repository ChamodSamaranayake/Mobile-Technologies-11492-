package com.example.mobiletechgroupproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton btnBarcode = findViewById(R.id.buttonBarcode);
        ImageButton btnContent = findViewById(R.id.buttonContent);
        ImageButton btnText    = findViewById(R.id.buttonText);

        btnBarcode.setOnClickListener(v -> openReader("Barcode Reader"));
        btnContent.setOnClickListener(v -> openReader("Content Reader"));
        btnText   .setOnClickListener(v -> openReader("Text Reader"));

        Button btnList = findViewById(R.id.buttonList);
        btnList.setOnClickListener(v ->
                startActivity(new Intent(this, ListActivity.class)));
    }

    private void openReader(String readerType) {
        Intent intent = new Intent(this, ReaderActivity.class);
        intent.putExtra("READER_TYPE", readerType);
        startActivity(intent);
    }
}