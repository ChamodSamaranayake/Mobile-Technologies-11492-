package com.example.mobiletechgroupproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;

public class DetailActivity extends AppCompatActivity {

    private String key, readerType, resultText, imageUriString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        key            = getIntent().getStringExtra("KEY");
        readerType     = getIntent().getStringExtra("READER_TYPE");
        resultText     = getIntent().getStringExtra("RESULT_TEXT");
        imageUriString = getIntent().getStringExtra("IMAGE_URI");

        TextView tvReader   = findViewById(R.id.tvReaderDetail);
        TextView tvResult   = findViewById(R.id.tvResultDetail);
        ImageView imageView = findViewById(R.id.imageViewDetail);

        tvReader.setText(readerType);
        tvResult.setText(resultText);

        if (imageUriString != null && !imageUriString.isEmpty())
            imageView.setImageURI(Uri.parse(imageUriString));
    }

    // Edit
    public void editItem(View view) {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra("READER_TYPE", readerType);
        intent.putExtra("RESULT_TEXT", resultText);
        intent.putExtra("FILENAME", key);
        intent.putExtra("IMAGE_URI", imageUriString);
        startActivity(intent);
    }

    // Delete
    public void deleteItem(View view) {
        FirebaseDatabase.getInstance().getReference("Storage")
                .child(key)
                .removeValue();

        Intent intent = new Intent(this, ListActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    // Cancel
    public void cancelItem(View view) {
        Intent intent = new Intent(this, ListActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}