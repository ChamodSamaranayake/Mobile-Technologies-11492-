package com.example.mobiletechgroupproject;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    List<MLKitResult> mlKitResults = new ArrayList<>();
    MLKitAdapter adapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle("List of Analysed Images");

        listView = findViewById(R.id.listView);
        adapter = new MLKitAdapter(this, R.layout.list_item, mlKitResults);
        listView.setAdapter(adapter);

        loadFromFirebase();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            MLKitResult res = mlKitResults.get(position);
            Intent intent = new Intent(ListActivity.this, DetailActivity.class);
            intent.putExtra("KEY", res.getKey());
            intent.putExtra("READER_TYPE", res.getReader());
            intent.putExtra("RESULT_TEXT", res.getResult());
            intent.putExtra("IMAGE_URI", res.getImageUri() != null
                    ? res.getImageUri().toString() : "");
            startActivity(intent);
        });
    }

    private void loadFromFirebase() {
        FirebaseDatabase.getInstance().getReference("Storage")
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot,
                                             @Nullable String previousChildName) {
                        String filename = snapshot.child("filename").getValue(String.class);
                        String reader   = snapshot.child("reader").getValue(String.class);
                        String text     = snapshot.child("text").getValue(String.class);

                        Uri imageUri = loadImageFromGallery(filename + ".png");

                        MLKitResult result = new MLKitResult(reader, text, imageUri);
                        result.setKey(filename);
                        mlKitResults.add(result);
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot,
                                               @Nullable String previousChildName) {
                        String filename = snapshot.child("filename").getValue(String.class);
                        String reader   = snapshot.child("reader").getValue(String.class);
                        String text     = snapshot.child("text").getValue(String.class);
                        for (MLKitResult r : mlKitResults) {
                            if (r.getKey().equals(filename)) {
                                r.setReader(reader);
                                r.setResult(text);
                                break;
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                        String filename = snapshot.getKey();
                        mlKitResults.removeIf(r -> r.getKey().equals(filename));
                        adapter.notifyDataSetChanged();
                    }

                    @Override public void onChildMoved(@NonNull DataSnapshot snapshot,
                                                       @Nullable String previousChildName) {}
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private Uri loadImageFromGallery(String filename) {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Images.Media._ID };
        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] args = { filename };
        try (Cursor cursor = getContentResolver().query(
                uri, projection, selection, args, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                long imageId = cursor.getLong(
                        cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                return ContentUris.withAppendedId(uri, imageId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void openAdd(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}