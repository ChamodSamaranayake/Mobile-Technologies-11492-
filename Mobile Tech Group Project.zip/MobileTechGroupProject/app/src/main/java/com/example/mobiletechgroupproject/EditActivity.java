package com.example.mobiletechgroupproject;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.OutputStream;

public class EditActivity extends AppCompatActivity {

    private String readerType;
    private String filename;
    private Uri sourceImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        readerType = getIntent().getStringExtra("READER_TYPE");
        String resultText = getIntent().getStringExtra("RESULT_TEXT");
        filename = getIntent().getStringExtra("FILENAME");
        String imageUriString = getIntent().getStringExtra("IMAGE_URI");

        // Convert the string back to a Uri
        if (imageUriString != null && !imageUriString.isEmpty()) {
            sourceImageUri = Uri.parse(imageUriString);
        }

        EditText tvReaderType = findViewById(R.id.tvReaderType);
        EditText editTextResult = findViewById(R.id.editTextResult);
        ImageView imageViewEdit = findViewById(R.id.imageViewEdit);
        Button buttonSave = findViewById(R.id.buttonSave);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(readerType);

        tvReaderType.setText(readerType);
        editTextResult.setText(resultText);

        // Show the image
        if (sourceImageUri != null) {
            imageViewEdit.setImageURI(sourceImageUri);
        } else {
            if ("Barcode Reader".equals(readerType))
                imageViewEdit.setImageResource(R.drawable.barcode);
            else if ("Content Reader".equals(readerType))
                imageViewEdit.setImageResource(R.drawable.content);
            else
                imageViewEdit.setImageResource(R.drawable.text);
        }

        buttonSave.setOnClickListener(v -> {
            String updatedText = editTextResult.getText().toString();
            String updatedReader = tvReaderType.getText().toString();

            // Save image to gallery
            if (sourceImageUri != null) {
                saveImageToGallery(filename, sourceImageUri);
            }

            // Save text to Firebase
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage");
            dbRef.child(filename).child("filename").setValue(filename);
            dbRef.child(filename).child("reader").setValue(updatedReader);
            dbRef.child(filename).child("text").setValue(updatedText);

            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, ListActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    // Save image to gallery
    private void saveImageToGallery(String fileName, Uri imageUri) {
        try {
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.Source source = ImageDecoder.createSource(
                        getContentResolver(), imageUri);
                bitmap = ImageDecoder.decodeBitmap(source);
            } else {
                bitmap = MediaStore.Images.Media.getBitmap(
                        getContentResolver(), imageUri);
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/Mobile Tech App");

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                OutputStream os = getContentResolver().openOutputStream(uri);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
                if (os != null) {
                    os.flush();
                    os.close();
                }
            }
        } catch (IOException e) {
            Log.e("SAVE_GALLERY", "Error saving image", e);
        }
    }
}