package com.example.mobiletechgroupproject;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MLKitAdapter extends ArrayAdapter<MLKitResult> {

    List<MLKitResult> items;

    public MLKitAdapter(@NonNull Context context, int resource,
                        @NonNull List<MLKitResult> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }

        MLKitResult item = items.get(position);

        ImageView icon = convertView.findViewById(R.id.imageViewListItem);
        TextView textViewItem = convertView.findViewById(R.id.textViewItem);

        if (item.getImageUri() != null) {
            icon.setImageURI(item.getImageUri());
        } else {
            icon.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        textViewItem.setText(item.getReader());

        if (position % 2 == 0) {
            convertView.setBackgroundColor(Color.LTGRAY); // Light Gray Colour
        } else {
            convertView.setBackgroundColor(Color.WHITE);
        }

        return convertView;
    }
}
